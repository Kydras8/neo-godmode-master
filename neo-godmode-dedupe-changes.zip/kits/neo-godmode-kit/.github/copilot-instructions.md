(copied from repo root) See top-level `.github/copilot-instructions.md` for full guidance.
